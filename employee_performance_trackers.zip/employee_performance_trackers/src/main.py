import pandas as pd
from .employee import Employee
from .storage import load_employees, add_employee
from .analysis import get_top_emp_performers, get_average_rating, get_employee_of_the_month, export_top_emp_performers
from .visualize import plot_performance_ratings, plot_tasks_vs_rating, plot_performance_pie


def display_menu():
    print("\nEmployee Performance Tracker")
    print("1. View All Employees")
    print("2. Add New Employee")
    print("3. View Top Performers")
    print("4. View Average Rating")
    print("5. View Employee of the Month")
    print("6. Export Top Performers")
    print("7. Visualize Performance Ratings")
    print("8. Visualize Tasks vs Rating")
    print("9. Visualize Piechart")
    print("10. Exit")

def main():
    while True:
        display_menu()
        choice = input("Enter your choice: ")
        if choice == '1':
            employees = load_employees()
            if employees:
                data = [emp.to_dict() for emp in employees]
                df = pd.DataFrame(data)
                print(df.to_string(index=False))
            else:
                print("No employees found.")
        elif choice == '2':
            name = input("Enter name: ")
            department = input("Enter department: ")
            hours = int(input("Enter hours worked: "))
            tasks = int(input("Enter tasks completed: "))
            rating = float(input("Enter performance rating: "))
            emp = Employee(name, department, hours, tasks, rating)
            add_employee(emp)
            print("Employee added successfully!")
        elif choice == '3':
            top = get_top_emp_performers()
            for emp in top:
                print(emp)
        elif choice == '4':
            avg = get_average_rating()
            print(f"Average Rating: {avg:.2f}")
        elif choice == '5':
            emp = get_employee_of_the_month()
            if emp:
                print(f"Employee of the Month is : {emp}")
            else:
                print("No employees found.")
        elif choice == '6':
            export_top_emp_performers()
            print("Top performers exported to data/top_performers.csv")
        elif choice == '7':
            plot_performance_ratings()
        elif choice == '8':
            plot_tasks_vs_rating()
        elif choice == '9':
            plot_performance_pie()
        elif choice == '10':
            break
        else:
            print("Invalid choice Please try again.")

if __name__ == "__main__":
    main()
