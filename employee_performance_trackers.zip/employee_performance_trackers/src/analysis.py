import csv
from .storage import load_employees

def get_top_emp_performers(n=3):
    employees = load_employees()
    sorted_employees = sorted(employees, key=lambda emp: emp.performance_rating, reverse=True)
    return sorted_employees[:n]

def get_average_rating():
    employees = load_employees()
    if not employees:
        return 0
    total_rating = sum(emp.performance_rating for emp in employees)
    return total_rating / len(employees)

def get_employee_of_the_month():
    employees = load_employees()
    if not employees:
        return None
    return max(employees, key=lambda emp: emp.performance_rating)

def export_top_emp_performers(filename='data/top_emp_performers.csv'):
    top_emp_performers = get_top_emp_performers()
    with open(filename, mode='w', newline='') as file:
        fieldnames = ['Employee_name', 'Department', 'Hours_worked', 'Tasks_completed', 'Performance_rating']
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        for emp in top_emp_performers:
            writer.writerow(emp.to_dict())
