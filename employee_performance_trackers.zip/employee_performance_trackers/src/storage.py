import csv
import os
from .employee import Employee

DATA_FILE = os.path.join('data', 'employees.csv')

def load_employees():
    employees = []
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, mode='r', encoding='utf-8-sig') as file:
            reader = csv.DictReader(file)
            for row in reader:
                row = {k.strip(): v.strip() for k, v in row.items()}
                emp = Employee(
                    row['Employee_name'],
                    row['Department'],
                    int(row['Hours_worked']),
                    int(row['Tasks_completed']),
                    float(row['Performance_rating'])
                )
                employees.append(emp)
    return employees

def save_employees(employees):
    with open(DATA_FILE, mode='w', newline='') as file:
        fieldnames = ['Employee_name', 'Department', 'Hours_worked', 'Tasks_completed', 'Performance_rating']
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        for emp in employees:
            writer.writerow(emp.to_dict())

def add_employee(employee):
    employees = load_employees()
    employees.append(employee)
    save_employees(employees)
