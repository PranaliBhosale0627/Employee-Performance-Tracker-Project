class Employee:
    def __init__(self, name: str, department: str, hours_worked: int, tasks_completed: int, performance_rating: float):
        self.name = name
        self.department = department
        self.hours_worked = hours_worked
        self.tasks_completed = tasks_completed
        self.performance_rating = performance_rating

    def __str__(self):
        return f"Name: {self.name}, Department: {self.department}, Hours Worked: {self.hours_worked}, Tasks Completed: {self.tasks_completed}, Rating: {self.performance_rating}"

    def to_dict(self):
        return {
            'Employee_name': self.name,
            'Department': self.department,
            'Hours_worked': self.hours_worked,
            'Tasks_completed': self.tasks_completed,
            'Performance_rating': self.performance_rating
        }
