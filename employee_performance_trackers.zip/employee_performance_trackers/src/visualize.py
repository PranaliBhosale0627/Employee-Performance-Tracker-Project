import os
import matplotlib.pyplot as plt
import seaborn as sns
from .storage import load_employees

PLOTS_DIR = os.path.join('data', 'plots')
os.makedirs(PLOTS_DIR, exist_ok=True)

def plot_performance_ratings():
    employees = load_employees()
    if not employees:
        print("No Employees to Visualize.")
        return

    names = [emp.name for emp in employees]
    ratings = [emp.performance_rating for emp in employees]

    plt.figure(figsize=(9, 7))
    sns.barplot(x=names, y=ratings, palette="Greens_d")
    plt.title('Employee Performance Ratings')
    plt.xlabel('Employee Name')
    plt.ylabel('Performance Rating')
    plt.xticks(rotation=0)
    plt.tight_layout()
    filename = os.path.join(PLOTS_DIR, 'performance_ratings.png')
    plt.savefig(filename)
    print(f"Chart saved as {filename}")
    plt.show()
    plt.close()

def plot_tasks_vs_rating():
    employees = load_employees()
    if not employees:
        print("No employees to visualize.")
        return
    tasks = [emp.tasks_completed for emp in employees]
    ratings = [emp.performance_rating for emp in employees]
    names = [emp.name for emp in employees]
    plt.figure(figsize=(11, 7))
    sns.scatterplot(x=tasks, y=ratings, s=300, color='red')
    for i, name in enumerate(names):
        plt.text(tasks[i] + 0.1, ratings[i], name, fontsize=9)
    plt.title('Tasks Completed vs Performance Rating')
    plt.xlabel('Tasks Completed')
    plt.ylabel('Performance Rating')
    plt.grid(True)
    plt.tight_layout()
    filename = os.path.join(PLOTS_DIR, 'tasks_vs_rating.png')
    plt.savefig(filename)
    print(f"Chart saved as {filename}")
    plt.show()
    plt.close()


def plot_performance_pie():
    employees = load_employees()
    if not employees:
        print("No employees to visualize.")
        return
    ratings = [emp.performance_rating for emp in employees]
    rating_counts = {}
    for rating in ratings:
        rating_counts[rating] = rating_counts.get(rating, 0) + 1
    labels = list(rating_counts.keys())
    sizes = list(rating_counts.values())
    plt.figure(figsize=(11, 7))
    plt.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=140)
    plt.title('Distribution of Performance Ratings')
    plt.axis('equal')
    plt.tight_layout()
    filename = os.path.join(PLOTS_DIR, 'performance_distribution.png')
    plt.savefig(filename)
    print(f"Chart saved as {filename}")
    plt.show()
    plt.close()
